
    io.to(user.room).emit('message', formatMessage(user.userna